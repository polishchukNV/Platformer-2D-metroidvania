﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Door : MonoBehaviour
{
    
    private void Start()
    {
        
    }

    public Door()
    {
    }

    private void Open(bool open)
    {

    }
}
